The class requires:
import java.util.Random;

